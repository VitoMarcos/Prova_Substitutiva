using Microsoft.EntityFrameworkCore;
using Alunos.models;
using Imcs.models;

namespace Banco.models;
public class AppDataContext : DbContext
{
    public DbSet<Aluno> alunos { get; set; }
     public DbSet<Imc> Imcs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=Vitor.db");
    }
}