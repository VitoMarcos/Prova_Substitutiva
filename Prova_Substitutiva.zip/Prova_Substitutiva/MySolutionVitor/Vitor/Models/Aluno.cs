namespace Alunos.models;
using Imcs.models;

public class Aluno{


public int Id {get; set;}

public string? Nome { get; set; }

public string? CPF { get; set; }

public List<Imc> Imcs { get; set; }

}