using Alunos.models;
namespace Imcs.models;

public class Imc
{


    public string ImcId { get; set; } = Guid.NewGuid().ToString();
    
    public Aluno aluno { get; set; }
    public double Altura { get; set; }

    public double Peso { get; set; }

    public double IMC { get; set; }

    public string? classificacao { get; set; }

    public int obesidade { get; set; }
}