﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vitor.Migrations
{
    /// <inheritdoc />
    public partial class AlteracoesNasClasses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AlunoId",
                table: "Imcs",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "classificacao",
                table: "Imcs",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "obesidade",
                table: "Imcs",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AlunoId",
                table: "Imcs");

            migrationBuilder.DropColumn(
                name: "classificacao",
                table: "Imcs");

            migrationBuilder.DropColumn(
                name: "obesidade",
                table: "Imcs");
        }
    }
}
