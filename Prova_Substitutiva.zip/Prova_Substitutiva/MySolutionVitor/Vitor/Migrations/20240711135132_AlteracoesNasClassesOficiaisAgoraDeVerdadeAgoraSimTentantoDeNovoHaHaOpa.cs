﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vitor.Migrations
{
    /// <inheritdoc />
    public partial class AlteracoesNasClassesOficiaisAgoraDeVerdadeAgoraSimTentantoDeNovoHaHaOpa : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_AlunoId",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "AlunoId",
                table: "Imcs",
                newName: "Alunoid");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_AlunoId",
                table: "Imcs",
                newName: "IX_Imcs_Alunoid");

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_Alunoid",
                table: "Imcs",
                column: "Alunoid",
                principalTable: "alunos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_Alunoid",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "Alunoid",
                table: "Imcs",
                newName: "AlunoId");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_Alunoid",
                table: "Imcs",
                newName: "IX_Imcs_AlunoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_AlunoId",
                table: "Imcs",
                column: "AlunoId",
                principalTable: "alunos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
