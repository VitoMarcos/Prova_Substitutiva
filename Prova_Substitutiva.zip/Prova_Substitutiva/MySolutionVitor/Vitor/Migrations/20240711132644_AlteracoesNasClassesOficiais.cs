﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vitor.Migrations
{
    /// <inheritdoc />
    public partial class AlteracoesNasClassesOficiais : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_alunoId",
                table: "Imcs");

            migrationBuilder.DropColumn(
                name: "AlunoId",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "alunoId",
                table: "Imcs",
                newName: "AlunoId");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_alunoId",
                table: "Imcs",
                newName: "IX_Imcs_AlunoId");

            migrationBuilder.AlterColumn<string>(
                name: "AlunoId",
                table: "Imcs",
                type: "TEXT",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_AlunoId",
                table: "Imcs",
                column: "AlunoId",
                principalTable: "alunos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_AlunoId",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "AlunoId",
                table: "Imcs",
                newName: "alunoId");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_AlunoId",
                table: "Imcs",
                newName: "IX_Imcs_alunoId");

            migrationBuilder.AlterColumn<string>(
                name: "alunoId",
                table: "Imcs",
                type: "TEXT",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "TEXT");

            migrationBuilder.AddColumn<int>(
                name: "AlunoId",
                table: "Imcs",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_alunoId",
                table: "Imcs",
                column: "alunoId",
                principalTable: "alunos",
                principalColumn: "Id");
        }
    }
}
