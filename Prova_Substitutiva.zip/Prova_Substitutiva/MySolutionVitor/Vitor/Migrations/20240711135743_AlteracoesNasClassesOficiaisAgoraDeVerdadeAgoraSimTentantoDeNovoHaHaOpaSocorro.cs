﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vitor.Migrations
{
    /// <inheritdoc />
    public partial class AlteracoesNasClassesOficiaisAgoraDeVerdadeAgoraSimTentantoDeNovoHaHaOpaSocorro : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_Alunoid",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "Alunoid",
                table: "Imcs",
                newName: "alunoId");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_Alunoid",
                table: "Imcs",
                newName: "IX_Imcs_alunoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_alunoId",
                table: "Imcs",
                column: "alunoId",
                principalTable: "alunos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Imcs_alunos_alunoId",
                table: "Imcs");

            migrationBuilder.RenameColumn(
                name: "alunoId",
                table: "Imcs",
                newName: "Alunoid");

            migrationBuilder.RenameIndex(
                name: "IX_Imcs_alunoId",
                table: "Imcs",
                newName: "IX_Imcs_Alunoid");

            migrationBuilder.AddForeignKey(
                name: "FK_Imcs_alunos_Alunoid",
                table: "Imcs",
                column: "Alunoid",
                principalTable: "alunos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
