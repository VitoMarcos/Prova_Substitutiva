using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Alunos.models;
using Imcs.models;
using Banco.models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<AppDataContext>();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

app.UseCors("AllowAll");

app.MapGet("/", () => "API da academia");

app.MapPost("/pages/aluno/cadastrar", ([FromBody] Aluno newAluno, [FromServices] AppDataContext ctx) =>
{

    Aluno? alunoEncontrado = ctx.alunos.FirstOrDefault(x => x.CPF == newAluno.CPF);
    if (alunoEncontrado is null)
    {
        ctx.alunos.Add(newAluno);
        ctx.SaveChanges();
        return Results.Created("", newAluno);
    }
    return Results.BadRequest("Já existe esse cpf no sistema");
});

app.MapPost("/pages/imc/cadastrar", ([FromBody] Imc imc, [FromServices] AppDataContext ctx) =>
{
    // //Validar se o aluno existe
    Aluno? alunoeu = ctx.alunos.Find(imc.aluno);

    if (alunoeu is null)
    {
        return Results.NotFound("Aluno não encontrado");
    }
    imc.aluno = alunoeu;

    // CALCULOS

    imc.IMC = imc.Peso / (imc.Altura * imc.Altura);

    //INTERPRETAÇÃO 

    if (imc.IMC < 18.5)
    {
        imc.classificacao = "Magreza";
        imc.obesidade = 0;
    }
    if (imc.IMC >= 18.5 && imc.IMC <= 24.9)
    {
        imc.classificacao = "Normal";
        imc.obesidade = 0;
    }
    if (imc.IMC >= 25 && imc.IMC <= 29.9)
    {
        imc.classificacao = "Sobrepeso";
        imc.obesidade = 1;
    }
    if (imc.IMC >= 30 && imc.IMC <= 39.9)
    {
        imc.classificacao = "Obesidade";
        imc.obesidade = 2;
    }
    if (imc.IMC > 40)
    {
        imc.classificacao = "Obesidade Grave";
        imc.obesidade = 3;
    }

    Imc? imcEncontrado = ctx.Imcs.FirstOrDefault(x => x.aluno == imc.aluno);
    if (imcEncontrado is null)
    {
        ctx.Imcs.Add(imc);
        ctx.SaveChanges();
        return Results.Created("", imc);
    }
    return Results.BadRequest("Já foi feito o imc deste aluno. Selecione a opção atualizar para fazer alterações");
});

app.MapGet("pages/imc/listar", ([FromServices] AppDataContext ctx) =>
{
    if (ctx.Imcs.Any())
    {
        return Results.Ok(ctx.Imcs.ToList());
    }
    return Results.NotFound("Não existe nada na tabela");
});

app.MapGet("/pages/imc/listarporaluno/{obesidade}", ([FromRoute] string classificacao, [FromServices] AppDataContext ctx) =>
{
    if (classificacao == "Magreza")
    {
        return Results.Ok(ctx.Imcs.Where(x => x.obesidade = 0).ToList());
    }
    if (classificacao == "Normal")
    {
        return Results.Ok(ctx.Imcs.Where(x => x.classificacao = "Normal").ToList());
    }
    if (classificacao == "Sobrepeso")
    {
        return Results.Ok(ctx.Imcs.Where(x => x.obesidade = 1).ToList());
    }
    if (classificacao == "Obesidade")
    {
        return Results.Ok(ctx.Imcs.Where(x => x.obesidade = 2).ToList());
    }
    if (classificacao == "Obesidade Grave")
    {
        return Results.Ok(ctx.Imcs.Where(x => x.obesidade = 3).ToList());
    }

});

app.MapPut("/pages/imc/alterar", ([FromRoute] string imcId, [FromBody] Imc imcAlterado, [FromServices] AppDataContext ctx) =>
{
    Imc? imc = ctx.Imcs.FirstOrDefault(x => x.ImcId == imcId);
    if (imc is null)
    {
        return Results.NotFound("Não encontrado!");
    }
    imc.aluno = imcAlterado.aluno;
    imc.Altura = imcAlterado.Altura;
    imc.Peso = imcAlterado.Peso;
   

    ctx.Imcs.Update(imc);
    ctx.SaveChanges();
    return Results.Ok("Tudo alterado!");
});

app.Run();

