import { ListFormat } from "typescript";

export interface Aluno {
    id: number;
    nome: string;
    cpf: string;
    Imcs: ListFormat;
}