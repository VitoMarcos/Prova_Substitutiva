import { Aluno } from "./aluno";

export interface Imc {
    id: number;
    aluno: Aluno;
    altura: number;
    peso: number;
    imc: number;
    classificacao: string;
    obesidade: number
}